﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp9
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (double.TryParse(textBox1.Text, out double x))
            {
                if (x < 0) textBox2.Text = GetResult(Math.Cos, 2 * x);
                else textBox2.Text = GetResult(Math.Sin, 2 * x);
            }
            else
            {
                textBox2.Text = "";
                MessageBox.Show("Данные введены неверно", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        delegate double Calculate(double argument);


        string GetResult(Calculate calculate, double arg)
        {
            return (arg + calculate(arg)).ToString("1.##");
        }







    }
}